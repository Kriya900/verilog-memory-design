# dual-port-ram
Supports simultaneous access from two independent ports. Each port has separate address, clock, and enable lines. Allows concurrent read and write operations.Verifies parallel read/write without data collision. Checks both port operations with separate timing. Waveforms confirm correct dual access behavior.
