# ROM
This project demonstrates the design of a synthesizable ROM in Verilog, along with a testbench to verify correct read functionality from preloaded memory values. Designed for learning and demonstration purposes in digital system design.
